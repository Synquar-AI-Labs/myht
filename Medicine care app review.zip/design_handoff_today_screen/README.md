# Handoff: "Today" Home Screen Redesign (option 2c)

## Overview
Redesign of the home ("Quick Log") screen of a family caregiving app used to coordinate care for a patient between multiple rotating caregivers. The core job of the screen is **shift handoff**: any caregiver opening the app must instantly answer two questions — *what has been done recently?* and *what do I do next?* — without hunting through tabs or dense grids.

The design replaces the current dense dashboard (summary stats, 9 quick-action buttons, 15 small medicine cards, 4 charts, 7 nav tabs) with a status-first timeline and progressive disclosure: detail lives one tap away in collapsible sections.

## About the Design Files
The file in this bundle (`today-screen-2c.html`) is a **design reference created in HTML** — a static prototype showing intended look and behavior, not production code to copy directly. The task is to **recreate this design in the target codebase's existing environment** using its established patterns and libraries.

**Target codebase context:** the existing app is a Vite + React + TypeScript project using Tailwind CSS, shadcn/ui components, TanStack Query, and Supabase (tables: health_records, medicines, medicine_logs, appointments, notes…). This screen replaces the current `QuickLogTab.tsx` home tab. Reuse the existing hooks (`useMedicines`, `useHealthRecords`, medicine-alert utilities in `src/lib/medicineAlerts.ts`) and shadcn primitives (e.g. `Collapsible`, `Drawer`) rather than introducing new libraries.

## Fidelity
**High-fidelity.** Colors, typography, spacing, and copy in the HTML are intentional. Recreate the UI pixel-perfectly, mapping colors/spacing onto the codebase's Tailwind theme (extend the theme where tokens don't exist yet). Data shown is sample data — all lists must be driven by real records.

## Screen: "Today" (home)

Single scrolling column, 390px design width (fluid on tablet — cap content at ~560px centered, or keep list full-width). Background `#faf7f2`, text `#26201a`.

### 1. Header
- Row, space-between, baseline-aligned. Padding 20px 20px 0.
- Left: current date, DM Serif Display 26px, e.g. "Monday, July 13".
- Right: live clock "8:47 PM", DM Sans 17px/600, color `#8a6240`.

### 2. Section: "GIVEN · LAST 12 HOURS"
- Section label: 14px/700, uppercase, letter-spacing 0.06em, color `#2e7d4f` (green). Margin-bottom 10px. Section padding 18px 20px 0.
- Card: white bg, 1px border `#e9e2d6`, radius 16px, inner padding 2px 16px.
- Rows: medicine **logs** from the last 12 hours, most recent first, **max 4 visible**.
  - Row: flex, gap 12px, padding 12px 0, 1px bottom divider `#f3ede2` (none on last).
  - Left: green check icon (lucide `check`, 20px, stroke `#2e7d4f`, stroke-width 3).
  - Middle (flex:1): medicine name 17px/700 + dose 17px/500 in `#8b8175` (e.g. "Metoclopramide 10 mg").
  - Right: time + caregiver name, 13px `#8b8175` (e.g. "8:05 PM · Affan").
- Footer row (inside card, top divider): "Show all 9 given" + chevron-down, 15px/600, `#8a6240`. Tapping expands the card to all logs from the window (chevron flips; label becomes "Show less").

### 3. Section: "COMING UP · NEXT 12 HOURS"
- Section label: same style but color `#c2410c`, preceded by a 10px dot in `#c2410c` pulsing with `duePulse` (opacity 1 → 0.55, 1.6s infinite). Section padding 22px 20px 0.
- Card: white bg, **1.5px border `#f0c9ae`**, radius 16px, padding 2px 16px.
- Rows: scheduled doses/tasks in the next 12 hours, soonest first, **max 4 visible**; same expand footer ("Show all 7 upcoming").
  - Left: time, 14px width 70px. Normal rows: 700 weight, `#8a6240`. Due rows: 800 weight, `#c2410c`.
  - Middle: item name 17px/700 + dose/amount in `#8b8175`.
- **Due-now flashing (the key interaction):** a row whose scheduled time is within ±5 minutes of now (reuse the tolerance logic in `medicineAlerts.ts`) gets:
  - Row background animation `dueFlashRow`: `rgba(194,65,12,.16)` → transparent, 1.2s infinite. Give the row radius 12px and padding 12px 10px with margin 2px -10px so the wash extends past the text.
  - A "DUE" badge on the right: 12px/800 uppercase white on `#c2410c`, radius 8px, padding 4px 8px, animated with `duePulse` 1.2s.
  - Rows NOT within 5 minutes never flash. Respect `prefers-reduced-motion` by substituting a static highlight.
- Marking a dose as given moves it into "Given" and logs time + current caregiver.

### 4. Collapsible sections (progressive disclosure)
Vertical stack, gap 8px, padding 22px 20px 24px. Each collapsed row is a white card: 1px border `#e9e2d6`, radius 16px, padding 14px 16px, flex with gap 14px, chevron-down at right (20px, `#8b8175`). Left icon chip: 40×40, radius 12px, 22px lucide icon. **The subtitle must answer the most common question without expanding.**

1. **Record a reading** — chip bg `#eaf3ec`, icon `heart` in `#2e7d4f`. Subtitle: "BP, feed, vomit, stool, weight… · last BP 118/76 at 2:15 PM" (live: latest reading). Expands to a 2-column grid of the 8 reading types (BP, Feed, Bile, Vomit, Stool, Urine, Weight, Flush), each a 52px-min tappable card with a 12px color dot, 16px/700 label, and 12px "today so far" subtitle; tapping opens the existing log drawer for that type.
2. **Record a medicine** — chip bg `#f3ecfb`, icon `pill` in `#8b5cf6`. Subtitle: "All 15 medicines · last: Metoclopramide, 8:05 PM". Expands to the full medicine list (name + dose, due/given/as-needed status per row) with one-tap logging.
3. **Appointments & notes** — chip bg `#eef1f9`, icon `calendar` in `#4f6bd6`. Subtitle: "Next: Dr. Chen — Mon, Jul 14 · 10:30". Expands to next appointment card + two outline buttons: "+ Appointment", "+ Note".
4. **Visuals & trends** — chip bg `#fdf0e6`, icon `bar-chart-3` in `#c2740c`. Subtitle: "Feeds, vomit, BP, weight, flush — weekly charts". Expands to the existing weekly charts (feeds/vomit/stool bars, flush bars, BP lines, weight line) — reuse the current chart components.

All sections start **collapsed** by default. Persist expanded state per session if trivial; default-collapsed on fresh open.

### 5. Bottom navigation — 3 tabs (down from 7)
- Bar: white bg, 1px top border `#e9e2d6`. Items: flex column, icon 24px + 13px label, padding 12px 0.
- Active ("Today"): color `#26201a`, label 700. Inactive: `#a49a8c`, label 600.
- Tabs: **Today** (clock icon) · **History** (bar-chart icon — full reports/records/calendar/transcripts live here) · **More** (ellipsis — settings, stays, everything else). The functions from the old 7 tabs are regrouped, not removed.

## Interactions & Behavior
- "Show all N" footers expand/collapse their card in place (animate max-height ~200ms ease-out; flip chevron).
- Due-row flash logic re-evaluates every minute (the app already ticks a clock — reuse it).
- Tapping a "Given" row could open the log entry for edit/undo (existing behavior).
- Collapsed section rows are full-row tap targets (min height 68px ≫ 44px minimum).
- All list rows are flex with explicit `gap` — no margin-based spacing.

## State Management
- `given12h: MedicineLog[]` and `upcoming12h: ScheduledItem[]` — derive from existing queries; both need `expanded: boolean` for show-all.
- `dueNow(item): boolean` — |scheduled − now| ≤ 5 min (reuse `medicineAlerts.ts` parsing of "10:00 AM / 9:00 PM" strings).
- Per-section `open` state for the four collapsibles.
- Caregiver identity for the "· Affan" attribution on logs — logs should store who logged them (add if the schema doesn't have it yet).

## Design Tokens
Colors:
- Background `#faf7f2`; card white `#ffffff`; page-on-tablet desk `#e8e4dc`
- Text primary `#26201a`; secondary `#8b8175`; muted nav `#a49a8c`
- Accent brown `#8a6240` (times, links, "show all")
- Green (done) `#2e7d4f`; chip bg `#eaf3ec`
- Orange (due) `#c2410c`; due card border `#f0c9ae`; flash wash `rgba(194,65,12,.16)`
- Borders: card `#e9e2d6`; row divider `#f3ede2`
- Section chips: purple `#8b5cf6` on `#f3ecfb`; blue `#4f6bd6` on `#eef1f9`; amber `#c2740c` on `#fdf0e6`

Typography: DM Serif Display (date header only, 26px); DM Sans everything else — 17px/700 row titles, 15px/600 actions, 14px/700–800 section labels (uppercase, 0.06em), 13px meta, 12px/800 DUE badge.

Spacing & shape: screen padding 20px; section gaps 18–22px; card radius 16px; inner radius 12px; row padding 12px 0; card borders 1px (1.5px for the due card).

Animations:
- `duePulse`: opacity 1 → 0.55 → 1 (badge 1.2s, section dot 1.6s)
- `dueFlashRow`: background `rgba(194,65,12,.16)` → transparent → back, 1.2s infinite

## Assets
No image assets. Icons are lucide-react (already in the codebase): check, heart, pill, calendar, bar-chart-3, clock, chevron-down, plus, file-text, ellipsis. Fonts: DM Sans + DM Serif Display (already used by the app, loaded from Google Fonts).

## Files
- `today-screen-2c.html` — the approved design reference (option 2c), self-contained; open in a browser to see layout and the due-row flash animation.
